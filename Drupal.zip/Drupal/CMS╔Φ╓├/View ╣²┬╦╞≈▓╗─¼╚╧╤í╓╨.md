过滤时设置不默认选中某一个选项
![[Pasted image 20230814154355.png]]

这样设置即可
![[Pasted image 20230814154421.png]]