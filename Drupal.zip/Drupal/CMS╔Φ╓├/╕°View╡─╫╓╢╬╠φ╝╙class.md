```php
配置view的时候可以给view的字段添加class

编辑字段页面---> style settings ---> Add HTML class
```
![[Pasted image 20230816170908.png]]
```php
效果图
```
![[Pasted image 20230816171123.png]]
