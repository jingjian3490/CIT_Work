```php
./d/sc/drush uri
```
