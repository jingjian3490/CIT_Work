使用`target="_blank"` 属性
```HTML
<a href="URL_HERE" target="_blank">链接文本</a>
```
